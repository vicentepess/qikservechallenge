import { HomePage } from "./pages/homepage/HomePage";
import  GlobalStyle from "./style/GlobalStyle"

function App() {
  return (
    <>
    <HomePage />
    <GlobalStyle />
    </>
  );
}

export default App;
